package atm.std.chatbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
